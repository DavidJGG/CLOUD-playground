# Enable AWS secrets engine
vault secrets enable aws

# Configure Vaut’s root access
vault write aws/config/root \
    access_key=AKIATPLNME26DI3KGIO6 \
    secret_key=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 \
    region=us-east-2

# Create role in Vault and link it to an AWS policy
# this role will allow users/apps to call the Lambda function via the API gateway
vault write aws/roles/dev-role \
    credential_type=iam_user \
    default_ttl=5m
    policy_document=-<<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "DevRoleInlinePolicy1",
            "Effect": "Allow",
            "Action": "apigateway:*",
            "Resource": "*"
        }
    ]
}
EOF

# Generate the credentials
vault read aws/creds/dev-role

# Control lease expiration
vault secrets tune -default-lease-ttl=5m aws/
vault secrets tune -default-lease-ttl=5m -max-lease-ttl=20m aws/

# Renew lease for 600 sec, or 10 min - within max_lease_ttl of 20 min - see above
vault lease renew -increment=600 my-lease-id
vault lease lookup aws/creds/dev-role/fZWeCwRT8l9xbRxrDoEpDRTe

# Revoke credentials
vault lease revoke aws/creds/dev-role/CdTx14Wl0m1kyUI6luKlEEsl



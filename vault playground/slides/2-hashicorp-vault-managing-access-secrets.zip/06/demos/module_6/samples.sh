vault read aws/creds/dev-role
Key                Value
---                -----
lease_id           aws/creds/dev-role/PHsJqJuWMfDMP0gBoYfZLDqV
lease_duration     768h
lease_renewable    true
access_key         AKIATPLNME26DOZTWH7S
secret_key         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
security_token     <nil>
# Install on Windows
choco install vault
vault version
vault -h

###################

# Install on Linux - Ubuntu
# For other Linux distributions, check out this link: 
# https://www.hashicorp.com/blog/announcing-the-hashicorp-linux-repository#curl-fssl-https-apt-releases-hashicorp-com-gpg-sudo-apt-key-add
curl -fsSL https://apt.releases.hashicorp.com/gpg | sudo apt-key add -
sudo apt-add-repository "deb [arch=amd64] https://apt.releases.hashicorp.com $(lsb_release -cs) main"
sudo apt-get update && sudo apt-get install vault

# Verify installation
ls -l /etc/apt/sources.list.d/ | grep hashi
vault -v

# Create a SystemD unit file called vault.service
sudo vim /etc/system/system/vault.service

# Paste the contents of vault.service found in the same folder alongside this file
# In the future, change the value ExecStart to work with the -config flag, and point to
# Vaults configuration file, when you want to run a Production instance of Vault

# Reload SystemD configuration
systemctl daemon-reload

# Start Vault service
systemctl start vault

# Enable Vault service to run on system boot
systemctl enable vault

# Check Vault service status - active (running | waiting | exited), inactive 
# (stopped), enabled | disabled …, see citation below
systemctl status vault

###################

# Install on Mac OS
# If you don't have Homebrew installed, use this command first
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

brew install hashicorp/tap/vault
vault version

# Install Consul as well
brew install consul


###################

# Install Consul on other OSs

# Ubuntu
sudo apt-get install -y consul

# Open SUSE
sudo snap install consul

# RedHat
sudo yum install -y consul 

# Debian - official repository added in 2020
sudo yum install -y consul

# Download module resources for full details and references  
# General command format
vault <command> [options] [path] [args]


# Sample command
vault write -address=“http://127.0.0.1:8200” auth/userpass/users/gsmith password=“pwd123”


# Sample command with multiple options and args
vault write -address=“http://127.0.0.1:8200” -namespace=“my-organization” \
auth/userpass/users/gsmith password=“pwd123” policies=“admin”

# Auto complete installation
vault -autocomplete-install
# After that execute Ctrl+C to stop Vault, then restart the dev server
vault server -dev
# Now vault read + tab will show you the autocomplete options for the "read" command
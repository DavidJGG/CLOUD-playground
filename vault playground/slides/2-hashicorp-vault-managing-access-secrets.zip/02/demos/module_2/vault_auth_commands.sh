# Enable on path auth/userpass
vault auth enable userpass

# Enable on path auth/userpass
vault auth enable \ 
    -description='UID/PWD Authentication Method' \
    -max-lease-ttl=2m \ 
    userpass/

# Enable LDAP auth method
vault enable ldap

# Configure LDAP auth method - basic parameters
vault write auth/ldap/config \
    url="ldap://ldap.globomantics.com" \
    userdn="ou=Users,dc=globomantics,dc=com" \
    groupdn="ou=Groups,dc=globomantics,dc=com" \
    groupfilter="(&(objectClass=group)(member:1.2.840.113556.1.4.1941:={{.UserDN}}))" \
    groupattr="cn" \
    upndomain="globomantics.com"

# Configure LDAP auth method - with CA cert enabled
vault write auth/ldap/config \
    url="ldap://ldap.globomantics.com" \
    userdn="ou=Users,dc=globomantics,dc=com" \
    groupdn="ou=Groups,dc=globomantics,dc=com" \
    groupfilter="(&(objectClass=group)(member:1.2.840.113556.1.4.1941:={{.UserDN}}))" \
    groupattr="cn" \
    upndomain="globomantics.com" \
    certificate=@ldap_ca_cert.pem \
    insecure_tls=false \
    starttls=true


# Set env variables for AWS
export AWS_ACCESS_KEY="my_aws_account_access_key128h*Y73#12<jd";
export AWS_SECRET_KEY="my_aws_account_secret_key93jkd&3)s>sds1";

# Enable AWS auth method
vault auth enable aws

# Configure AWS auth method with the access and secret keys
vault write auth/aws/config/client \
	secret_key=$AWS_SECRET_KEY \
	access_key=$AWS_ACCESS_KEY

# Create a policy that gives db-role list and read capabilities
vault policy write db-policy - << EOF
path "database/creds/app-role" {
	capabilities = ["list", "read"]
}
EOF

# Create and configure app-db-role
vault write \
    auth/aws/role/app-db-role \
    auth_type=ec2 \
    policies=db-policy \
    max_ttl=1h \
    disallow_reauthentication=false \
    bound_ami_id=ami-<hash>

# Read the policy to verify it is correctly configured
vault read auth/aws/role/app-db-role


# List first level commands
vault -h

# Get help on first level commands
vault <command> -h

# Get help on subcommands
vault <command> <subcommand> -h

# Sample subcommand
vault lease renew -h

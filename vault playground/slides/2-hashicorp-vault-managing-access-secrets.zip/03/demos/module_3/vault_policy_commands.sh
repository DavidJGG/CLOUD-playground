# Create a policy
vault policy write my-policy ./my-policy.hcl
vault policy write other-policy ./other-policy.hcl

vault policy write profileapp-policy profileapp-policy.hcl 
vault policy write ecommdev-policy ecommdev-policy.hcl

vault policy write profileapp-policy ./profileapp-policy.hcl
vault policy write other-policy ./other-policy.hcl

# Assign policies to token
vault token create -policy=my-policy -policy=other-policy
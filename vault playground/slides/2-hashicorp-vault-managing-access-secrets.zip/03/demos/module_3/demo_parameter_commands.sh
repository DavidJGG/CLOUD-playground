# Enable KVv1 secrets engine on this specific path
vault login root
vault auth enable userpass # If not yet enabled
vault secrets enable -version=1 -path=secretv1 -description="KVv1 for Policy Parameter Testing" kv

# 1) Allowed
# Upload the  with allowed parameters - contains only "create" capability (important)
# This policy is for a user who can only create secrets
vault policy write demo_policy_with_parameters_allowed demo_policy_with_parameters_allowed.hcl

# Upload corresponding read-only policy for another user who will only be able to read the secrets
vault policy write demo_policy_with_parameters_allowed_readonly demo_policy_with_parameters_allowed_readonly.hcl

# Create two users - one to create (write) secrets and the other to read those secrets
vault write auth/userpass/users/aptester password=aptester policies=demo_policy_with_parameters_allowed
vault write auth/userpass/users/aptesterro password=aptesterro policies=demo_policy_with_parameters_allowed_readonly

vault login -method=userpass username=aptester password=aptester
vault kv put secretv1/constrained-allowed/secret1 # Fails with "Must supply data" error message
vault kv put secretv1/constrained-allowed/secret1 uid=1 # Works
vault kv put secretv1/constrained-allowed/secret2 title_name=Prince-Harry # Fails with 403: permission denied
vault kv put secretv1/constrained-allowed/secret2 title_name=Queen-Latifah # Works
vault kv put secretv1/constrained-allowed/secret3 uid=3 title_name=King-George # Works
vault kv put secretv1/constrained-allowed/secret4 status=ruling # Fails with 403: permission denied

vault login -method=userpass username=aptesterro password=aptesterro


# 2) Denied
vault login root
vault policy write demo_policy_with_parameters_denied demo_policy_with_parameters_denied.hcl
vault policy write demo_policy_with_parameters_denied_readonly demo_policy_with_parameters_denied_readonly.hcl

vault write auth/userpass/users/dptester password=dptester policies=demo_policy_with_parameters_denied
vault write auth/userpass/users/dptesterro password=dptesterro policies=demo_policy_with_parameters_denied_readonly
vault login -method=userpass username=dptester password=dptester
vault login -method=userpass username=dptesterro password=dptesterro

vault kv put secretv1/constrained-allowed/secret1 status=ready # Works
vault kv put secretv1/constrained-denied/secret2 auditor_name="Hutch" # Fails
vault kv put secretv1/constrained-denied/secret2 auditor_name="Smith" # Works


# 3) Required
vault policy write demo_policy_with_parameters_required demo_policy_with_parameters_required.hcl
vault policy write demo_policy_with_parameters_required_readonly demo_policy_with_parameters_required_readonly.hcl

vault write auth/userpass/users/rptester password=rptester policies=demo_policy_with_parameters_required
vault write auth/userpass/users/rptesterro password=rptesterro policies=demo_policy_with_parameters_required_readonly

vault login -method=userpass username=rptester password=rptester
vault login -method=userpass username=rptesterro password=rptesterro
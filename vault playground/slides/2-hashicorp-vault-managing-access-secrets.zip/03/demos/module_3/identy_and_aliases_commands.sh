# Upload policies
vault policy write base base_policy.hcl
vault policy write devteam devteam_policy.hcl
vault policy write training training_policy.hcl

# Create users, aka identities
vault write auth/userpass/users/developer password="devpwd" policies="devteam"
vault write auth/userpass/users/trainer password="trainpwd" policies="training"

# Find the mount accessor for the userpass authentication - Path Column = userpass/, Accessor Column = auth_userpass_<id_string>
vault auth list -detailed
brew install jq
vault auth list -format=json | jq -r '.["userpass/"].accessor' > userpass_accessor.txt

# Create entity; generated ID: 2bb0437b-4708-5076-dca8-15d79e26aea8
vault write identity/entity name="george-smith" policies="base" \
        metadata=organization="Globomantics Inc." \
        metadata=devteam="The A Team" \
        metadata=secondrole="trainer"

# Add users to entity as aliases
vault write identity/entity-alias name="developer" \
        canonical_id="2bb0437b-4708-5076-dca8-15d79e26aea8" \
        mount_accessor=$(cat userpass_accessor.txt)

vault write identity/entity-alias name="trainer" \
        canonical_id="2bb0437b-4708-5076-dca8-15d79e26aea8" \
        mount_accessor=$(cat userpass_accessor.txt)

# Verify users are present as aliases within the entity
vault read identity/entity/id/2bb0437b-4708-5076-dca8-15d79e26aea8

# Log in as "trainer" and write a secret
vault login -method=userpass username=trainer password=trainpwd
vault kv put secret/training created_by="trainer"
vault token capabilities secret/data/devteam # Fails with "deny" error message; we need to login as "developer"

# Log in as "developer" and write a secret
vault login -method=userpass username=developer password=devpwd
vault kv put secret/devteam created_by="developer"



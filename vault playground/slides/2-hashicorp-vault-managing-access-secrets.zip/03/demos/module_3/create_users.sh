# Create orgops user and assign a policy
vault write auth/userpass/users/orgops password=orgops policies=demo_glob_myorg_ops_policy

# Login with orgops user
vault login -method=userpass username=orgops password=orgops

# Write to myorg
vault kv put secret/myorg/opsorgsecret1 key=opsbadge2371 value=super13secret45pwd

# Write to myorg/mydepartment
vault kv put secret/myorg/mydepartment/opsdeptsecret1 key=opsbadge2371 value=super13secret45pwd

# Expected error - permission denied - when attempting to write to myorg/admin-secert
vault kv put secret/myorg/admin-secret key=opsbadge2371 value=super13secret45pwd

###     ###

# Create orgadmin user and assign a policy
vault write auth/userpass/users/orgadmin password=orgadmin policies=demo_glob_myorg_admins_policy,demo_glob_myorg_ops_policy
vault list auth/userpass/users

# Login with orgops user
vault login -method=userpass username=orgadmin password=orgadmin

# Write to myorg
vault kv put secret/myorg/adminorgsecret1 key=adminsbadge007 value=doubleO13secret45pwd

# Write to myorg/mydepartment
vault kv put secret/myorg/mydepartment/admindeptsecret1 key=adminsbadge007 value=doubleO13secret45pwd

# Write to myorg/admin-secret
vault kv put secret/myorg/admin-secret/adminorgsupersecret key=adminsbadge007 value=doubleO13secret45pwd

# Create orgrep user and assign a policy
vault write auth/userpass/users/orgrep password=orgrep policies=demo_wildcard_policy

vault kv put secret/org2/unit1/accounting/team1 key=orgrepbadge1010 value=010734
vault kv put secret/org2/unit2/finance/team3 key=orgrepbadge1111 value=050501

vault kv get secret/org2/unit1/accounting/team1
vault kv get secret/org2/unit2/finance/team3

vault kv put secret/org2/unit3/finance/loans/team4 key=orgrepbadge2222 value=060606
vault kv get secret/org2/unit3/finance/loans/team4

# User for testing policy with parameters
vault write auth/userpass/users/paramtester password=paramtester policies=demo_policy_with_parameters
# Create log file and change its permissions to make it writable by Vault
sudo touch /var/log/vault_audit.log && sudo chown gsyyl:staff /var/log/vault_audit.log

# Log in as root and enable the file audit device
vault login root && vault audit enable file file_path=/var/log/vault_audit.log

# Enable socket audit device
vault audit enable socket address=127.0.0.1:9090 socket_type=tcp log_raw=true
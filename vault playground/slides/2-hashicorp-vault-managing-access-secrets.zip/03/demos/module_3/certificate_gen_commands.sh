### Step 1: Choose one of the following keystor types: JKS (older) or PKCS12 (newer) - the latter is used in this course

# Generate key pair for a certificate for keystore of type JKS
keytool -genkeypair \
    -alias springboot \ 
    -keyalg RSA \
    -keysize 4096 \
    -storetype JKS \
    -keystore springboot.jks \
    -validity 3650 \
    -storepass password

# Generate key pair for a certificate for keystore of type PKCS12
keytool -genkeypair \
    -alias springboot \ 
    -keyalg RSA \
    -keysize 4096 \
    -storetype PKCS12 \
    -keystore springboot.p12 \
    -validity 3650 \
    -storepass password



### Step 2: Respond to questions

# Just hit enter for all questions that follow when you execute the command
# except when you are asked to confirm the information is correct: type "yes" and hit enter


### Step 3: Verify keystore content
keytool -list -v -keystore springboot.jks
# OR
keytool -list -v -keystore springboot.p12

### !!! Remove this later - convert an existing JKS store to a PKCS12 store
keytool -importkeystore -srckeystore springboot.jks -destkeystore springboot.p12 -deststoretype pkcs12

### !!! Remove this later - import an existing certificate
keytool -import -alias springboot -file myCertificate.crt -keystore springboot.p12 -storepass password




### Step 4: Enable HTTPs in Spring Boot

# Extract SSL certificate from keystore
keytool -export -keystore springboot.p12 -alias springboot -file springboot_app.crt
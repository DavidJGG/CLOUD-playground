### ON MAC OS - Catalina ###
# Allow you terminal (or your IDE, like VS Code, if you prefer) full disk access - see the screenshot: enable_full_disk_access_on_mac.png

# Enable/disable SSHD on Mac by executing
sudo systemsetup -setremotelogin on

# Execute install_vault_ssh_helper.sh as root
sudo -s
chmod +x install_vault_ssh_helper.sh 

# Enable ssh secrets engine
vault secrets enable ssh

# Create vaultadmin role; vsshuser is the username we will specify when connecting to the ssh server
# cidr_list=0.0.0.0/0,0.0.0.0/0 - this range specifies we can connect from anywhere to the ssh server
vault write ssh/roles/vaultadmin \
    key_type=otp \
    default_user=vsshuser cidr_list=0.0.0.0/0,0.0.0.0/0

### ON UBUNTU ###
# .bashrc
export VAULT_ADDR=http://localhost:8200

# Create config director for the Vault SSH Helper and palce the its config file in it
sudo mkdir /etc/vault-ssh-helper.d/
sudo cp -p vault-ssh-helper.hcl

# Test Vault SSH Helper
vault-ssh-helper -dev -verify-only -config=/etc/vault-ssh-helper.d/config.hcl

# Install SSHD
apt-get update && apt-get install -y openssh-server

# Modify SSH Config
auth requisite pam_exec.so quiet expose_authtok log=/tmp/vaultsshhelper.log /usr/local/bin/vault-ssh-helper -dev -config=/etc/vault-ssh-helper.d/config.hcl
auth optional pam_unix.so not_set_pass use_first_pass nodelay

# Create user that will connect to Vault server
adduser vsshuser

### ON MAC OS - Catalina ###
# Generate one-time password (OTP)
vault write ssh/creds/vaultadmin ip=10.0.2.15

# Grab the key value from the output of the previous command
# Try to connect to the SSH server and enter the password just obtained
ssh vsshuser@localhost -p 2222

# After you connect successfully, log out, and try connecting again using the same passowrd
# That will fail because you alerady used the password once
# Enable port forwarding in VirtualBox - VM > Settings > Network  > Port Forwarding - open port 22 on 127.0.1.1 
# and that will forward traffic to port 22 of 10.0.2.15 - internal address of your VM
# OTP: 05dbd824-b832-5454-ac87-7b88f2bc6abf
ssh vsshuser@localhost -p 2222

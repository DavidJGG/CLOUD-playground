# Install MySQL
brew install mysql

# Start the database - runs as a daemon
brew services start mysql

# To start it on the foreground
mysql.server start
mysql.server stop


# Secure the database - by default there is not root password
mysql_secure_installation
# Press y|Y for Yes, any other key for No: Type N, as this database is just for testing purposes, and thus you don't need to test password strength
# Remove anonymous users? (Press y|Y for Yes, any other key for No) : again type N
# Disallow root login remotely? (Press y|Y for Yes, any other key for No) : type N
# Remove test database and access to it? (Press y|Y for Yes, any other key for No) : type N
# Reload privilege tables now? (Press y|Y for Yes, any other key for No) : type Y
# Success.
# All done!

# Test the installation
mysql -u root -p         
# Sample Output
# Enter password: 
# Welcome to the MySQL monitor.  Commands end with ; or \g.
# Your MySQL connection id is 10
# Server version: 8.0.26 Homebrew

# Copyright (c) 2000, 2021, Oracle and/or its affiliates.

# Oracle is a registered trademark of Oracle Corporation and/or its
# affiliates. Other names may be trademarks of their respective
# owners.

# Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

# mysql> 
mysql> show databases;
# +--------------------+
# | Database           |
# +--------------------+
# | information_schema |
# | mysql              |
# | performance_schema |
# | sys                |
# +--------------------+
# 4 rows in set (0.00 sec)

# mysql> 
mysql> quit
# Bye

brew install --cask mysqlworkbench
# In Finder, go to /Applications, find MySQLWorkbench, right click, select Open => you will still get a warning but you have the option to open the app
# OR try the following command (don't forget to type the exact version of MySQL in the path below):
# xattr -d com.apple.quarantine /usr/local/Cellar/mysql/8.0.26/bin/mysqld
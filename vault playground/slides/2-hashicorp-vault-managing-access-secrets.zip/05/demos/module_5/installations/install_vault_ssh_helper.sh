#!/bin/bash

# The instructions below were tested on Ubuntu 20.04
wget https://releases.hashicorp.com/vault-ssh-helper/0.2.1/vault-ssh-helper_0.2.1_linux_386.zip
unzip vault-ssh-helper_0.2.1_linux_386.zip
mv vault-ssh-helper /usr/local/bin
export VAULT_ADDR=http://localhost:8200/
rm vault-ssh-helper_0.2.1_linux_386.zip
# Enable the PKI secrets engine
vault secrets enable pki

# Tune it to last for 10 years
vault secrets tune -max-lease-ttl=87600h pki

# Generate the Root CA certificate
vault write -field=certificate pki/root/generate/internal \
     common_name="globo.com" \
     ttl=87600h > CA_cert.crt

# Expose URLs for issuing certificates and for CRL distribution
vault write pki/config/urls \
     issuing_certificates="$VAULT_ADDR/v1/pki/ca" \
     crl_distribution_points="$VAULT_ADDR/v1/pki/crl"

# Create the Intermediate CA - expose the PKI secrets engine via another path - in this case pki_int (int stands for intermediate)
vault secrets enable -path=pki_int pki

# tune the engine to last for 5 years
vault secrets tune -max-lease-ttl=43800h pki_int

# Create CSR (Certificate Signing Request)
vault write -format=json pki_int/intermediate/generate/internal \
     common_name="globo.com Intermediate Authority" \
     | jq -r '.data.csr' > pki_intermediate.csr

# Sign the CSR with the Root CA's private key
vault write -format=json pki/root/sign-intermediate csr=@pki_intermediate.csr \
     format=pem_bundle ttl="43800h" \
     | jq -r '.data.certificate' > intermediate.cert.pem

# Import that Intermediate CA’s certificate into Vault
vault write pki_int/intermediate/set-signed certificate=@intermediate.cert.pem

# Alright, we can now create a role via the Intermediate Certificate Authority that will apply to subdomains as well.
vault write pki_int/roles/globo-dot-com \
     allowed_domains="globo.com" \
     allow_subdomains=true \
     max_ttl="720h"

# Request certificates from Vault
vault write pki_int/issue/globo-dot-com common_name="test.globo.com" ttl="24h"

# Request certificates from Vault via the API
curl --header "X-Vault-Token: $VAULT_TOKEN" \
    --request POST \
    --data '{"common_name": "test.globo.com", "ttl": "24h"}' \
    $VAULT_ADDR/v1/pki_int/issue/globo-dot-com | jq


# Revoke the certificates and keep track of them with CRLs
# Providing the serial number of the certificate to the revoke path
vault write pki_int/revoke \
    serial_number="0e:5b:ef:cc:87:48:d2:ca:d0:a5:eb:b8:23:eb:73:50:61:9c:65:7a"

Output:
Key                        Value
---                        -----
revocation_time            1631929100
revocation_time_rfc3339    2021-09-18T01:38:20.621149Z


# Remove the certificate:
vault write pki_int/tidy tidy_cert_store=true tidy_revoked_certs=true

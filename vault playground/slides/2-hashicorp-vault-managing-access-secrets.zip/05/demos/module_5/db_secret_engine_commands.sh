# Enable the database secrets engine
vault secrets enable database

# Configure the db engine
vault write database/config/mysql \
    plugin_name=mysql-database-plugin \
    connection_url="{{username}}:{{password}}@tcp(localhost:3306)/" \
    allowed_roles="reader,writer" \
    username="root" \
    password="sup3rm1sqlp@ss0rd"

# Create reader role
vault write database/roles/reader \
    db_name=mysql \
    creation_statements="CREATE USER '{{name}}'@'%' IDENTIFIED BY '{{password}}'; GRANT SELECT ON *.* TO '{{name}}'@'%';" \
    default_ttl="2h" \
    max_ttl="48h"

# Create writer role
vault write database/roles/writer \
    db_name=mysql \
    creation_statements="CREATE USER '{{name}}'@'%' IDENTIFIED BY '{{password}}'; GRANT ALL ON *.* TO '{{name}}'@'%';" \
    default_ttl="2h" \
    max_ttl="48h"

# Upload the policies
vault policy write reader reader.hcl
vault policy write writer writer.hcl

# Create tokens, log in, and create credentials with the reader role
vault token create -policy=reader
vault login s.CMFWtkvmgubnhzlVLgBARAP9
vault read database/creds/reader
# Now log in to the database with the generated credentials
mysql -uv-token-reader-20mJBKAAIg4AKwKOy -pnJsaAAZto-CL0pjIUwzV -h localhost
show databases;
use datbase mysql;
create database globomanticsdb; # Fails because reader role and its corresponding user have only read (SELECT) privileges


# Create tokens, log in, and create credentials with the writer role
vault login s.hWQw5bdWpRaLX5klhup7CpAz # as root
vault token create -policy=writer
vault login s.9iII1yhhTocogoR7wULCVQ02
vault read database/creds/writer
# Now log in to the database with the generated credentials
mysql -uv-token-writer-x43s0MOPjCEl6zvkb -pnRG7iHGRC6-dVhrU5uVh -h localhost
create database globomanticsdb; # Success; the writer role and its corresponding user have create (ALL) privileges
show databases;
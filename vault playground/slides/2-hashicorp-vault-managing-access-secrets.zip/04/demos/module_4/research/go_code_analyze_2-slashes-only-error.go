func parseIamArn(iamArn string) (*iamEntity, error) {

        // iamArn should look like one of the following:

        // 1. arn:aws:iam::<account_id>:<entity_type>/<UserName>

        // 2. arn:aws:sts::<account_id>:assumed-role/<RoleName>/<RoleSessionName>

        // if we get something like 2, then we want to transform that back to what

        // most people would expect, which is arn:aws:iam::<account_id>:role/<RoleName>

        var entity iamEntity

        fullParts := strings.Split(iamArn, ":")

        if len(fullParts) != 6 {

                return nil, fmt.Errorf("unrecognized arn: contains %d colon-separated parts, expected 6", len(fullParts))

        }

        if fullParts[0] != "arn" {

                return nil, fmt.Errorf("unrecognized arn: does not begin with \"arn:\"")

        }

        // normally aws, but could be aws-cn or aws-us-gov

        entity.Partition = fullParts[1]

        if fullParts[2] != "iam" && fullParts[2] != "sts" {

                return nil, fmt.Errorf("unrecognized service: %v, not one of iam or sts", fullParts[2])

        }

        // fullParts[3] is the region, which doesn't matter for AWS IAM entities

        entity.AccountNumber = fullParts[4]

        // fullParts[5] would now be something like user/<UserName> or assumed-role/<RoleName>/<RoleSessionName>

        parts := strings.Split(fullParts[5], "/")

        if len(parts) < 2 {

                return nil, fmt.Errorf("unrecognized arn: %q contains fewer than 2 slash-separated parts", fullParts[5])

        }

        entity.Type = parts[0]

        entity.Path = strings.Join(parts[1:len(parts)-1], "/")

        entity.FriendlyName = parts[len(parts)-1]

        // now, entity.FriendlyName should either be <UserName> or <RoleName>

        switch entity.Type {

        case "assumed-role":

                // Check for three parts for assumed role ARNs

                if len(parts) < 3 {

                        return nil, fmt.Errorf("unrecognized arn: %q contains fewer than 3 slash-separated parts", fullParts[5])

                }

                // Assumed roles don't have paths and have a slightly different format

                // parts[2] is <RoleSessionName>

                entity.Path = ""

                entity.FriendlyName = parts[1]

                entity.SessionInfo = parts[2]

        case "user":

        case "role":

        case "instance-profile":

        default:

                return &iamEntity{}, fmt.Errorf("unrecognized principal type: %q", entity.Type)

        }

        return &entity, nil

}
There is a possibility that your syntax might be wrong for iamarn? 


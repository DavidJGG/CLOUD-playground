# Initial Root Token: s.eBTNuAn5nZi4sQzkwRzErwkC
# Create the directory for the certs and get vault to own it
sudo mkdir /opt/vault/ca
sudo chown vault:vault /opt/vault/ca
sudo cd /opt/vault/ca 

# Generate the server cert
sudo openssl genrsa -out server.key.pem 4096
hostname # pop-os
sudo openssl req -new -key server.key.pem -out server.csr

# Create server_cert_ext.cnf with the following content
basicConstraints = CA:FALSE
nsCertType = server
nsComment = "OpenSSL Generated Server Certificate"
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer:always
keyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth

# Generate the server cert
openssl x509 -req -in server.csr -passin file:mypass.enc -CA /root/tls/intermediate/certs/ca-chain-bundle.cert.pem -CAkey /root/tls/intermediate/private/intermediate.cakey.pem -out server.cert.pem -CAcreateserial -days 365 -sha256 -extfile server_cert_ext.cnf
# The above is too much. Use the instructions below from Ned Bellavance


# Self signed keys
sudo mkdir /etc/vault/certs
sudo openssl req -new -newkey rsa:4096 -x509 -sha256 -days 365 -nodes -out /etc/vault/certs/vault_cert.crt
sudo chown --recursive vault:vault /etc/vault/certs
sudo chmod 750 --recursive /etc/vault/certs

# Add certificates - using "letsencrypt"
sudo mkdir /etc/vault/certs
sudo add-apt-repository ppa:certbot/certbot -y
sudo apt-get update
sudo apt-get install certbot -y
sudo certbot certonly --standalone --email gsmithpluralsight@gmail.com -d vault-1.globomantics.xyz --agree-tos
sudo cp /etc/letsencrypt/live/vault-1.globomantics.xyz/fullchain.pem /etc/vault/certs/vault_cert.crt
sudo cp /etc/letsencrypt/live/vault-1.globomantics.xyz/private.key /etc/vault/certs/vault_cert.key
sudo chown 750 --recursive vault:vault /etc/vault/certs
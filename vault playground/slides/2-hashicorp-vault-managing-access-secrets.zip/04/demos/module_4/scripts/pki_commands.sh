###########################
#      Set up Root CA     #
###########################
# Enable cert secrets engine
vault secrets enable pki
# Bump up the max lease ttl to 10 years
vault secrets tune -max-lease-ttl=87600h pki
# Generate root cert
vault write -format=json pki/root/generate/internal \
common_name=”vault-ca-root-pki” | tee \
>(jq -r .data.certificate > vault-ca-root-pki.pem) \
>(jq -r .data.issuing_ca > vault-ca-root-pki-issuing.pem) \
>(jq -r .data.private_key > vault-ca-root-pki-key.pem)
# Setup CRL and issuiing URL
vault write pki/config/urls issuing_certificates="http://127.0.0.1:8300/v1/pki/ca" crl_distribution_points="http://127.0.0.1:8300/v1/pki/crl"
# Create intermediate CA
vault secrets enable -path=pki_int pki
vault secrets tune -max-lease-ttl=43800h pki_int
# Generate intermediate CA signed request
vault write -format=json pki_int/intermediate/generate/internal \
common_name="vault-ca-root-pki Intermediate Authority" \
| jq -r '.data.csr' > vault-ca-root-pki-int.csr
# Setting up our Intermediate CA requires signing our CSR using our Root CA
vault write -format=json pki/root/sign-intermediate csr=@vault-ca-root-pki-int.csr \
common_name="vault-ca-root-pki-int" \
format=pem_bundle ttl="43800h" \
| jq -r '.data.certificate' > vault-ca-root-pki-int.pem
#  Inject intermediate certificate into Intermediate CA config
vault write pki_int/intermediate/set-signed certificate=@vault-ca-root-pki-int.pem
# Configure URL
vault write pki_int/config/urls issuing_certificates="http://127.0.0.1:8300/v1/pki_int/ca" crl_distribution_points="http://127.0.0.1:8300/v1/pki_int/crl"

###########################
# Authenticate with Cert  #
###########################
# Enable cert auth method
vault auth enable cert
# Enable the PKI secrets engine at path "pki_int"
vault secrets enable -path=pki_int pki # Done previously because I executed the command as part of authentication below

# Create a role
vault write pki_int/roles/vault-cert allow_any_name=true max_ttl="1440h" generate_lease=true

# Upload the policy
vault policy write vault-cert vault-cert.hcl

# Generate certificates
vault write -format=json pki_int/issue/vault-cert \
common_name="vault-cert" | tee \
>(jq -r .data.certificate > vault-cert-certificate.pem) \
>(jq -r .data.issuing_ca > vault-cert-issuing-ca.pem) \
>(jq -r .data.private_key > vault-cert-private-key.pem)

# Upload the certificate to Vault and specify the policy for the users of that certificate
vault write auth/cert/certs/vault-cert \
display_name=vault-cert \
policies=vault-cert \
certificate=@vault-cert-certificate.pem

# Log in with our certs
vault login -method=cert -client-cert=vault-cert-certificate.pem -client-key=vault-cert-private-key.pem name=vault-cert 


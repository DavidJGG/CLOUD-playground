# These are the general commands
vault token renew [<token_id> | <accessor_id>]
vault token revoke [<token_id> | <accessor_id>]

# Retrieve wrapped secret
curl --header "X-Vault-Token: s.yNv0oTjfHWnjLfACF8QOPS6V" --request POST $VAULT_ADDR/v1/sys/wrapping/unwrap | jq

# Create secret and then wrap existing secret
vault kv put secret/db-admin pwd=dbadmin_pwd
vault kv get -wrap-ttl=420 secret/db-admin

# Generate and store a token as a secret in a cubbyhole 
vault token create -wrap-ttl=420 -policy=devteam
vault unwrap s.tqLs8VbA7lLjvOHSwFifpU9a
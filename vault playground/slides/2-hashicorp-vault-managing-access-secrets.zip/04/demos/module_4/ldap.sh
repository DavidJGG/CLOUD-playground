# Enable and configure LDAP authentication method; cn=vaultadmin sn=vaultadmin userPassword=vaultadmin
# billykid, pwd=b1g23f0ot, same for gcharm user
# groupdn="ou=groups,ou=system" \
# groupfilter="(&(objectClass=person)(cn={{.Username}}))" \
vault auth enable ldap
vault write auth/ldap/config \
url="ldap://example.com:10389" \
userattr="cn" \
userdn="cn=vaultadmin,ou=users,ou=system" \
groupdn="ou=groups,ou=system" \
groupfilter="(|(memberUid={{.Username}})(member={{.UserDN}})(uniqueMember={{.UserDN}}))"
binddn="cn=vaultadmin,ou=users,ou=system" \
bindpass="vaultadmin" \
groupattr="uniqueMember" \
insecure_tls=true \
starttls=false

# Valid search base:
# cn=vaultadmin,ou=users,ou=system
# filter="(objectClass=*)" \ - to filter users but is not part of the Vault documentation

# Upload the policy
vault policy write devteam devteam_policy.hcl

# Create a user group in vault to match the setup on the LDAP server
vault write auth/ldap/groups/devstars policies=devteam

# No need to create a user in vault - vaultadmin with password "vaultadmin" was already created on the LDAP server
vault login -method=ldap username=vaultadmin
    
# Log in with LDAP method
vault login -method=ldap username=vaultadmin

# Sample search
# LDAP Search Example
ldapsearch -h localhost -p 10389 -x -b "dc=example,dc=com" 'cn=billykid'

# which returned
# extended LDIF
#
# LDAPv3
# base <dc=example,dc=com> with scope subtree
# filter: cn=billykid
# requesting: ALL
#

# search result - "my note: the next two lines did not have a comment #, I put it in."
# search: 2
# result: 0 Success

# numResponses: 1
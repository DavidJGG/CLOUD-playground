# Enable KV secrets engine
vault secrets enable -path=secret kv

# Write some test data
vault kv put secret/awsauthdemo/config ttl=10m username=devuser password=b3st4secret

# Upload a simple policy to read and list the secrets under the path above
vault policy write awsauth awsauth.hcl

# Enable AWS authentication method
vault auth enable aws

# Configure the AWS credentials
vault write auth/aws/config/client secret_key=N8F8L3CmthvxwHrGPjoALBjRe9khWFxrfbCma/y9 access_key=AKIATPLNME26BEGUOLUL

# Create AWS policy and role, then attach the policy to the role
aws iam create-policy --policy-name vault-docs-awsauth-policy --policy-document file://awsauth_recommended_policy.json
aws iam create-role --role-name vault-aws-auth-role --assume-role-policy-document file://vault-aws-auth-role.json
aws iam attach-role-policy --role-name vault-aws-auth-role --policy-arn arn:aws:iam::239136941756:policy/vault-docs-awsauth-policy

# Create the vault-aws-auth-role manually in AWS IAM console and attach to it the vault-docs-awsauth-policy just created above
# Or user the attach-role-policy iam command, as shown above
# To use this: delete prior versions: aws iam delete-policy --policy-arn arn:aws:iam::<aws_account_number>:policy/vault-docs-awsauth-policy
# Create a Vault role and associate it with an AWS role that has the custom policy we create previously
# bound_iam_principal_arn="arn:aws:iam::<aws_account_number>:role/vault-aws-auth-role" \
# /RoleSessionName
# bound_iam_principal_arn="arn:aws:iam::<aws_account_number>:user/*" \
# bound_iam_principal_arn="arn:aws:iam::<aws_account_number>:role/vault-aws-auth-role" \
# vault write auth/aws/role/awsauth-role-iam \
#     auth_type=iam \
#     bound_iam_principal_arn="arn:aws:iam::<aws_account_number>:role/vault-aws-auth-role" resolve_aws_unique_ids=true \
#     policies=awsauth ttl=24h

# Works OK, with IAM user vaultiam (created manually via IAM console)
vault write auth/aws/role/awsauth-role-iam \
    auth_type=iam \
    bound_iam_principal_arn="arn:aws:iam::239136941756:user/vaultiam" resolve_aws_unique_ids=true \
    policies=awsauth ttl=48h

# Allow any Principal to log in - tested OK
vault write auth/aws/role/awsauth-role-iam \
    auth_type=iam \
    bound_iam_principal_arn="arn:aws:iam::239136941756:*" resolve_aws_unique_ids=true \
    policies=awsauth ttl=48h

# Configure X-Vault-AWS-IAM-Server-ID Header - recommended
vault write auth/aws/config/client iam_server_id_header_value=vault.example.com

# Log in - IAM auth method
vault login -method=aws header_value=vault.example.com role=awsauth-role-iam
vault login -method=aws header_value=vault.example.com role=awsauth-role-iam aws_access_key_id=AKIATPLNME26BEGUOLUL aws_secret_access_key=N8F8L3CmthvxwHrGPjoALBjRe9khWFxrfbCma/y9
vault login -method=aws header_value=vault.example.com role=awsauth-role-iam aws_access_key_id=<IAM_user_access_key> aws_secret_access_key=<IAM_user_secret_key>




# Caching
vault secrets enable -path="secret" kv
vault kv put secret/myapp/config ttl='30s' username='appuser' password='suP3rsec(et!'
vault policy write myapp myapp.hcl
vault auth enable aws
vault write -force auth/aws/config/client

vault write auth/aws/role/app-role auth_type=iam bound_iam_principal_arn="arn:aws:iam::${account_id}:role/${role_name}" policies=myapp ttl=24h

vault auth enable userpass
vault write auth/userpass/users/student password="pAssw0rd" policies="myapp" ttl=48h
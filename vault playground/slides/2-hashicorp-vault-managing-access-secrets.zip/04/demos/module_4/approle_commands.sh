# Create a secret
vault kv put secret/devops/jenkinssecret uid=dbadmin pwd=sup3rb@dsEcr1t

# Enable AppRole authentication method
vault auth enable approle

# Upload Jenkins policy to Vault
vault policy write jenkins jenkins.hcl

# Create Vault role and link it to the policy above
vault write auth/approle/role/jenkins policies=jenkins

# Get the role-id a and generate a secret-id
vault read auth/approle/role/jenkins/role-id
vault write -f auth/approle/role/jenkins/secret-id
# role_id    97bab030-871b-31ba-1f7c-3b1036d7cc55
# secret_id             8805d584-c12e-9b34-4f33-bb596b968467
# secret_id_accessor    f75eef4e-fb88-f745-dafa-3ee5b671a87c
# secret_id_ttl         0s
# Description: Jenkins will use these credentials to authenticate to Vault

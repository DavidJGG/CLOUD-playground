# Create a policy for testing
vault policy write devteam devteam_policy.hcl

# Create a regular token without specifying a ttl or a max - we specify policy to avoid creating another root token
vault token create -policy=devteam_policy

# Create regular token with ttl equal to 30 seconds and max ttl equalt to 60 seconds
vault token create -policy=devteam -ttl=30s -explicit-max-ttl=60s

# Now look up that token - a few seconds have already passed
vault token lookup s.BwARi6fEspJyQPYE4cJZTpOI

# Create Use Limit token
vault token create -policy=devteam -ttl=30s -explicit-max-ttl=60s -use-limit=3
vault token create -policy=devteam -ttl=2m -explicit-max-ttl=4m -use-limit=3
vault login <token>

# Login as root
# Enable userpass authentication method
vault login root
vault auth enable userpass

# Create a sample user and log in with that user
vault write auth/userpass/users/tokentester password=tokentester policies=devteam
vault login -method=userpass username=tokentester password=tokentester

# Attempt to create periodic token
vault token create -policy=devteam -period=6h # Fails because we are not root or sudo user

# Try with root
vault login root # Specify your root token instead of "root", if you did not speciy "root" as the token when staritng Vault
vault token create -policy=devteam -period=6h # OK

# Create short-lived token
vault token create -policy=devteam -ttl=15s

# Create orphan token
vault login -method=userpass username=tokentester password=tokentester
vault token create -orphan
vault login root
vault token create -orphan

# Crate a batch token
vault token create -type=batch -policy=devteam -ttl=30m
# For Mac
# For other OSs visit the main link and look in the left sidebase: https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html
curl "https://awscli.amazonaws.com/AWSCLIV2.pkg" -o "AWSCLIV2.pkg"
sudo installer -pkg AWSCLIV2.pkg -target /

# Uninstall
#Find the folder that contains the symlinks to the main program and the completer.
which aws
# /usr/local/bin/aws

# Using that information, run the following command to find the installation folder that the symlinks point to.
ls -l /usr/local/bin/aws
# lrwxrwxrwx 1 ec2-user ec2-user 49 Oct 22 09:49 /usr/local/bin/aws -> /usr/local/aws-cli/aws
# Delete the two symlinks in the first folder. If your user account already has write permission to these folders, you don't need to use sudo.
sudo rm /usr/local/bin/aws
sudo rm /usr/local/bin/aws_completer

# To UNINSTALL, delete the main installation folder. Use sudo to gain write access to the /usr/local folder.
sudo rm -rf /usr/local/aws-cli
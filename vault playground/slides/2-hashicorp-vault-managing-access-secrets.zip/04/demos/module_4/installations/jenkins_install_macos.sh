# Install the latest LTS version 
brew install jenkins-lts

# Get intiial admin password
sudo cat /Users/$(whoami)/.jenkins/secrets/initialAdminPassword

# Install a specific LTS version: 
brew install jenkins-lts@YOUR_VERSION

# Start/restart/stop/ the Jenkins service: 
brew services start jenkins-lts
brew services restart jenkins-lts
brew services stop jenkins-lts

# Upgrade the Jenkins version: 
brew upgrade jenkins-lts